ufvm v 1.0
Open-source package for academic use done by CFD group @ AUB.
contact us at: cfd@aub.edu.lb

Note:
Remember to add '~/uFVM/src' directory to your path in Matlab by calling: addpath(genpath('~paste here the location of uFVM directory~/uFVM/src'));

