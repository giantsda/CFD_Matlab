function cfdCorrectMdotAndVelocityFields
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================

cfdCorrectMdotField;

cfdCorrectVelocityField;

end