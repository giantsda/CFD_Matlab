function cfdCorrectVelocityEquation(theEquationName,iComponent)
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================

cfdCorrectScalarEquation(theEquationName,iComponent);

end