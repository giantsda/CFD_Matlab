function m = cfdMagnitude(V)

m = sqrt(dot(V',V'))';


