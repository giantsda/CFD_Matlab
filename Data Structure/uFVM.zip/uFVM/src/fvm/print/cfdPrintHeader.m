function cfdPrintHeader

fprintf('                          Starting Solution\n');