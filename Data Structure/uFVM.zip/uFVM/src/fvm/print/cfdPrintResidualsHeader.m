function cfdPrintResidualsHeader

fprintf('|--------------------------------------------------------------------------|\n');
fprintf('|  Equation  |     RMS     |     MAX     | initialResidual | finalResidual |\n');
fprintf('|--------------------------------------------------------------------------|\n');