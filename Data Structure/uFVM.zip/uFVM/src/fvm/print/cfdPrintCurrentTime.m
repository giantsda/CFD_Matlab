function cfdPrintCurrentTime(currentTime)

fprintf('\n\n%s %d \n', 'Time: ', currentTime);