function isMoving = cfdIsMoving

global Domain;
isMoving = Domain.isMoving;
end