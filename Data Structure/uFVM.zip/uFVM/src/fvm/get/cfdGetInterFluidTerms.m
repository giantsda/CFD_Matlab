function theInterFluidTerms = cfdGetInterFluidTerms
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================

global CFDEnv;

theInterFluidTerms = CFDEnv.interfluidTerms;