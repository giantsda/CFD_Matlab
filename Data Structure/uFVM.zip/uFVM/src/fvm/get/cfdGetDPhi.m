function dphi = cfdGetDPhi
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================

theCoefficients = cfdGetCoefficients;
dphi = theCoefficients.dphi;