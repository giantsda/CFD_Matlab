function theAlgorithm = cfdGetAlgorithm
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================


global Domain;

theAlgorithm = Domain.algorithm;