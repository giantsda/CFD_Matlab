function theContFluidIndex=cfdGetContFluidIndex;
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================

global CFDEnv;

theContFluidIndex=CFDEnv.interfluidTerms{1}.iFluid1;

end