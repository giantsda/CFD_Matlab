function n = cfdGetNumberOfElements
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================


m=cfdGetMesh;
n = m.numberOfElements