function fdt = cfdGetFalseDt
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================
global Domain;

fdt = Domain.time.fdt;

end