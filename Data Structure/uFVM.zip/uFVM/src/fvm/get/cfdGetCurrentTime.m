function currentTime = cfdGetCurrentTime

global Domain

currentTime = Domain.time.currentTime;

end