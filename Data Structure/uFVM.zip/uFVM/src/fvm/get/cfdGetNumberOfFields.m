function theNumberOfFields = cfdGetNumberOfFields
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================


    theNumberOfFields = length(cfdGetModels);
