function theTime = cfdGetConditions
%===================================================

%  written by the CFD Group @ AUB, Fall 2016
%===================================================


global Domain;

theTime = Domain.time;