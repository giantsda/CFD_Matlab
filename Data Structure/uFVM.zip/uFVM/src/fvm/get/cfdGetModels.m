function theFields = cfdGetModels
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================


global Domain;

theFields = Domain.fields;
