function theNumberOfInterFluidTerms = cfdGetNumberOfInterFluidTerms;
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================

theNumberOfInterFluidTerms = length(cfdGetAllInterFluidTerms);


