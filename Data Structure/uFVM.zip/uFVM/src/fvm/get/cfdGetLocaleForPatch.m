function theBPatch = cfdGetLocaleForPatch(iPatch)



if(iPatch==1)     
    theBPatch='BPatch01';
elseif(iPatch==1) 
    theBPatch='BPatch01';
elseif(iPatch==2) 
    theBPatch='BPatch02';
elseif(iPatch==3) 
    theBPatch='BPatch03';
elseif(iPatch==4) 
    theBPatch='BPatch04';
elseif(iPatch==5) 
    theBPatch='BPatch05';
elseif(iPatch==6)
    theBPatch='BPatch06';
elseif(iPatch==7)   
    theBPatch='BPatch07';
elseif(iPatch==8) 
    theBPatch='BPatch08';
elseif(iPatch==9) 
    theBPatch='BPatch09';
elseif(iPatch==10) 
    theBPatch='BPatch10';
elseif(iPatch==11) 
    theBPatch='BPatch11';
elseif(iPatch==12) 
    theBPatch='BPatch12';
elseif(iPatch==13) 
    theBPatch='BPatch13';
elseif(iPatch==14) 
    theBPatch='BPatch14';
elseif(iPatch==15) 
    theBPatch='BPatch15';
end
