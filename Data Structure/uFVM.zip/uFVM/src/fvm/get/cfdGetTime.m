function time = cfdGetTime

global Domain

time = Domain.time;

end