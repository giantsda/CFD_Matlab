function cfdSetMesh(theMesh)

global Domain;

%-----------------------------------------
% add mesh to CFDEnv
%-----------------------------------------
Domain.mesh = theMesh;





