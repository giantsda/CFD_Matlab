function cfdSetConditions(theConditions)
%===================================================

%  written by the CFD Group @ AUB, Fall 2016
%===================================================

global Domain;

Domain.time = time;