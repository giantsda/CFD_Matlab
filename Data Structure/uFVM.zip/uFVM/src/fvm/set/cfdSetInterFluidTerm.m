function cfdSetInterFluidTerm(theInterfluidTerm)

global Domain

Domain.interfluidTerms = [Domain.interfluidTerms theInterfluidTerm];