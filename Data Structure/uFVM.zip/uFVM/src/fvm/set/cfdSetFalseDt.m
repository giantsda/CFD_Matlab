function cfdSetFalseDt(dt)

global Domain

Domain.dt = dt;

end