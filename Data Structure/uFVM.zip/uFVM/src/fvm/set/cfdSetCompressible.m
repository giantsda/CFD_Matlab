function cfdSetCompressible(trueOrFalse)
%
%
%
global Domain;
Domain.isCompressible = trueOrFalse;