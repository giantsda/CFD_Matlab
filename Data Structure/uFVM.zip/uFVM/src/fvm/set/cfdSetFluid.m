function cfdSetFluid(theFluid)

global Domain;


    
    Domain.fluids{theFluid.index}=theFluid;
