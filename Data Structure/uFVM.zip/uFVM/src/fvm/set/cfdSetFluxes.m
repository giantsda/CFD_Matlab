function cfdSetFluxes(theFluxes)

global Domain;

Domain.fluxes = theFluxes;