function cfdSetFigure(theFigureName)

global CFDEnv

CFDEnv.figure=figure('name',theFigureName);