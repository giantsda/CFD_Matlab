function cfdSetCurrentTime(currentTime)

global Domain

Domain.time.currentTime = currentTime;

end