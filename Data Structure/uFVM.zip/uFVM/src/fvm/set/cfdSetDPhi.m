function cfdSetDPhi(dphi)
%===================================================

%  written by the CFD Group @ AUB, Fall 2006
%===================================================

theCoefficients = cfdGetCoefficients;
theCoefficients.dphi = dphi;