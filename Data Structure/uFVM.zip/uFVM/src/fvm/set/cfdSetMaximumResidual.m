function cfdSetMaximumResidual(maxResidual)


global CFDEnv


CFDEnv.MAXResidual = maxResidual;