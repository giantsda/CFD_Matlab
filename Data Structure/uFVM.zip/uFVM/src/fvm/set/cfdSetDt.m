function cfdSetDt(deltaT)

global Domain

Domain.time.deltaT = deltaT;

end