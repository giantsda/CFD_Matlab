path='E:\desktop\temp\Dr Peers Reactor\2\';
for i=1:1:998
    name=[path num2str(i) '.jpg'];
    im=imread(name);
    for i=1:3
%     rim(:,:,i)=rot90(im(:,:,i));
%     lim(:,:,i)=rot90(im(:,:,i),3);
%     uim(:,:,i)=rot90(im(:,:,i),2);
    mlrim(:,:,i)=fliplr(im(:,:,i));
%     mudim(:,:,i)=flipud(im(:,:,i));
    end
    imshow(mlrim)
end
