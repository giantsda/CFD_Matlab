filename='E:\desktop\temp\light result of_69 13-43.xls'
data = importdata(filename);
light=data;
number=size(light);
light(:,2)=light(:,2)/1.2/30;
% hist(light(:,2),300)
% xlim([0 1])
id=[];
%%
for i=1:1:number
   if light(i,2)>=0.1 &&  light(i,2)<=0.2
       id=[id (light(i,1))];
   end
end
%% assa
figure;
long=size(id);
long=long(2);
set(gcf,'outerposition',get(0,'screensize'));
clear M;
i=1;
for ii=1:1:long
    e=id(ii)   ;
    e=relation(e);
matrixsize=size(particle{e});
matrixsize=matrixsize(1);
if matrixsize ~=0
lightintegral=0;  %initial interal 
f=0;
    for f=1:1:matrixsize-1
          if particle{e}(f,1) <= timelimit
                timestep=(particle{e}(f+1,1)-particle{e}(f,1)); % timestep=t2-t1
                        x1=100*particle{e}(f,3);%convert m to cm
                        x2=100*particle{e}(f+1,3);%convert m to cm
                        y1=100*particle{e}(f,4);  %store z position                          
                        y2=100*particle{e}(f+1,4);%store z position
                        z1=100*particle{e}(f,5);%convert m to cm
                        z2=100*particle{e}(f+1,5);%convert m to cm                        
                        light1=1.2/(exp(3*(x1)));   %state the light function           
                        light2=1.2/(exp(3*(x2)));  %state the light function        
%                                     light1=get_light(x1,y1,15);
%                                     light2=get_light(x2,y2,15);
%                                                             light1=1.2/(exp(3*(z1)));   %state the light function           
%                                                             light2=1.2/(exp(3*(z2)));  %state the light function                                
                integral=(light1+light2)*timestep/2;  %integral
                lightintegral=lightintegral+integral;
          else
          break;
          end
      end
lightin=lightintegral;%create a column vector so I can add it to vector [light]
%%
xp=100*particle{e}(:,3);
yp=100*particle{e}(:,4);
zp=100*particle{e}(:,5);
    subplot(1,2,1)   
    plot3(xp, zp,yp,'LineWidth',0.5);
%       hold on;
    xlabel('x')
    ylabel('z')
    zlabel('y')
    axis equal
    xlim([-5  2.5])
    ylim([0 7])
    zlim([-1 10])
    text(0,0,10,[ 'Nomolized Light intensity Integration is   ' num2str(lightin/timelimit/1.2)]);
%%
subplot(1,2,2)
plot3(xp, zp,yp,'LineWidth',0.5);
%   hold on;
xlabel('x')
    ylabel('z')
    zlabel('y')
axis equal
    xlim([-5  2.5])
    ylim([0 7])
    zlim([-1 10])
az = 0; 
el = 0;
view(az, el);  
% pause( 0.00001);      
end
 M(i)=getframe(gcf);
 i=i+1;
end
%  movie2avi(M,'E:\desktop\temp\3.avi','FPS',30,'quality',100) 