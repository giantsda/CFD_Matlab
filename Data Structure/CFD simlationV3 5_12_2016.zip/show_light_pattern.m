% % function show_light_pattern (particle, number_m)
% 
% clear;
% folder_path='E:\desktop';
% file_name='export';
% filename1 = [folder_path '\' file_name '.csv'] 
% delimiterIn = ',';
% headerlinesIn = 6;
% data = importdata(filename1,delimiterIn,headerlinesIn);
% xposition=data.data(:, 1); %store data into column vecter;
% yposition=data.data(:, 2);
% zposition=data.data(:, 3);
% particleid=data.data(:, 4);
% particletime=data.data(:, 5);
%     ber=size(particleid);%find how manys rows do I have ; ber is a vecter
%     rownumber=ber(1);
%     number_m=1; %number of different particle
% %
% for i=1:1:rownumber-1
%     if particleid(i) ~= particleid(i+1)
%         number_m=number_m+1;
%     end
% end  
% particle=cell(1,number_m);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
% j=1; %calculate times of jth particle repeating
% repeat=ones(1,number_m); %k is a 1*number vector used to record repeat times 
% for i=1:1:rownumber-1
%     if particleid(i)== particleid(i+1)
%         repeat(j)=repeat(j)+1;
%     else
%         j=j+1;
%     end
% end
% c=0;
% for a=1:1:number_m  %for ath partocle
%    for b=1:1:repeat(a) %store line data for repeat(a) times 
%     particle{a}(b,1)=particletime(c+1);
%     particle{a}(b,2)=particleid(c+1);
%     particle{a}(b,3)=xposition(c+1);
%     particle{a}(b,4)=yposition(c+1);
%     particle{a}(b,5)=zposition(c+1);
%     c=c+1;
%    end  
% end
% fprintf('store all data to particle.............. \n');

%%
i=1;
MinPeakProminence=0.6;
number=number_m;
pksnum=[];
maxtime=particle{5}(end,1)
figure;
set(gcf,'outerposition',get(0,'screensize'));
timevector=[];
for d=1:1:number_m         % calcuate the avarage time period
    matrixsize=size(particle{d});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
            time=particle{d}(:,1);
            time=time(end);
            if isnan(time) == 0
                      timevector=[timevector time];
            end
            d=d+1;
     end
end
max_time=median(timevector);
for e=1:1:500
e=randi([1 number-3]);
matrixsize=size(particle{e});
matrixsize=matrixsize(1);
if matrixsize ~=0
time=particle{e}(:,1);
xp=100*particle{e}(:,3);
yp=100*particle{e}(:,4);
zp=100*particle{e}(:,5);
%%
subplot(2,2,1)   
plot3(xp, zp,yp,'LineWidth',0.5);
xlabel('x')
ylabel('z')
zlabel('y')
axis equal
xlim([-3.15 3.15])
ylim([-3.15 3.15])
zlim([0 30])
title('spatial position history');
%% find number of peaks
subplot(2,2,2)
plot(time,xp);
ylim([-3.15 3.15])
title('xposition history');
xlabel('time (s)')  
ylabel('xposition')
% hold on;
% [pks,locs]=findpeaks(xp,'MinPeakProminence',MinPeakProminence);
% pksnum_i=size(pks);
% pksnum_i=pksnum_i(1); 
% pksnum=[pksnum pksnum_i];
% pks_ave=mean(pksnum);
% plot(time(locs),xp(locs),'o')
%% 
subplot(2,2,3)
plot(time,yp);
ylim([0 30])
title('yposition history');
xlabel('time (s)')
ylabel('xposition')
% hold on;
% [pks2,locs2]=findpeaks(yp,'MinPeakProminence',MinPeakProminence);
% pksnum_i=size(pks2);
% pksnum_i=pksnum_i(1);
% pksnum=[pksnum pksnum_i];
% pks_ave=mean(pksnum);
% plot(time(locs2),yp(locs2),'o')
%% 
lightz=1.2./(exp(0.3*(yp)));  %state the light function
subplot(2,2,4)  
plot(time,lightz);
ylim([0 1.2]);
title('light integration history'); 
xlabel('time (s)')
ylabel('light integration')
% suptitle(['This the history of Particle position=' num2str(e) ';  local peak#='  num2str(pksnum_i)  ';   ' ...
%     'average peak# =' num2str(pks_ave) '; average time period =' ...
%     num2str(max_time/pks_ave) ';  ' num2str(i) 'of 500'  ]);
end
pause( );
%  M(i)=getframe(gcf);
 i=i+1;
end 
% movie2avi(M,'E:\desktop\temp\light_pattern.avi','FPS',5,'quality',100) 
