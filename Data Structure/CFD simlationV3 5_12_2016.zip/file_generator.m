older_path = 'E:\desktop\CFD\Dr Peers Reactor\PT'; 
for i=11:1:20
i=num2str(i);    
path=[older_path '\' i]
mkdir(path); 
end
