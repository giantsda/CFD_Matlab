function report (light, mediantime,gas,number,del,timelimit,timelimitfactor,folder_path,file_name,line_vector)
avetimestep=mediantime;  %(particle{1}(i,1)-particle{1}(1,1))/i;
gaslenth =size(gas);
gaslenth=gaslenth(1,2);
left=size(light);
left=left(2);
maxintegral=1.2*timelimit;
sma=0;      
for i=1:1:left
   if light(2,i) <  maxintegral*0.01
       sma=sma+1;
   end
end
light_001=[];
for i=1:1:left
   if light(2,i) >  maxintegral*0.01
      light_001=[light_001 light(:,i)];
   end
end
x=light(1,:);    
y=light(2,:);
    average=mean(y); %calcuate average
    variance=var(y); % calcuate variance
        [ma,g]=max(y); % find the largest one `
        g=light(1,g);
        [mi,h]=min(y); % find the smallest one    
        hh=light(1,h);
%%
figure(1);
nbins = 300;    %define figure elements
histfit(y,nbins);  % generate a figure of light distribution
xlabel('Total light intensity');
ylabel('repeat times');
title(['Light distribution of_' file_name '_' ]);
    saveas(gcf,[folder_path '\' 'Light distribution of_' file_name  '.bmp']);
%%
figure(2);
x_001=light_001(1,:);    
y_001=light_001(2,:);
nbins = 300;    %define figure elements
histfit(y_001,nbins);  % generate a figure of light distribution
xlabel('Total light intensity');
ylabel('repeat times');
title(['Light distribution of_particles larger than 0.01\_\_' file_name '_' ]);
   saveas(gcf,[folder_path '\' 'Light distribution of_particles larger than 0.01__of ' file_name  '.bmp']);
%%
diary([folder_path '\' 'Report of'  file_name  '.txt'])
report1 = 'In this case %2.0f particles are tracked which %2.0f of them are escaped.Medium time step is %5.6fs  \n';
fprintf(report1,number,gaslenth,avetimestep)
report2 = '%2.0f particles are deleted because the time period is less than %2.2f *ave. Total line number is %6.0f \n';
fprintf(report2,del,timelimitfactor,sum(line_vector))
report3= 'integration time period is %5.6fs. there are %3.0f particles left \n';
fprintf(report3,timelimit,left)
report4 = 'The average of total light intensity is<<%4.5f>>. The variance is %4.5f; \nThe largest one is %4.5f of ID %4.0f; The smallest one is %4.5f of ID %4.0f. \n';
fprintf(report4,average,variance,ma,g,mi,hh)
report5 = 'The light intensity function is  __light1=1.2/(exp(300*x))__ maxium integral is%5.6f. \n';
fprintf(report5,maxintegral)
report6= 'The average over the maxium integral is<<%4.5f>> and%5.0f particles (%5.2fpercent) are smaill than 0.01*max \n';
fprintf(report6,average/maxintegral,sma,sma/left*100)
lightxls=light.';
name= [folder_path '\' file_name '.xls'];
xlswrite (name,lightxls); % generate a column excel file to save ID and Light
diary off;