function [particle,number_m,repeat,line_vector] = unsteady_read_and_store (folder_path, file_name,file_repeat,line_vector);
s=num2str(file_repeat);
delimiterIn = ','; %read txt file
headerlinesIn = 6;
filename1= [folder_path '\' file_name '_' s '.csv'] ;  
data = importdata(filename1,delimiterIn,headerlinesIn);
xposition=data.data(:, 1); %store data into column vecter;
yposition=data.data(:, 2);
zposition=data.data(:, 3);
particleid=data.data(:, 4);
particletime=data.data(:, 5);
ber=size(particleid);%find how manys rows do I have ; ber is a vecter
rownumber=ber(1);
line_vector=[line_vector rownumber];
number_m=1; %number of different particle
%%
for i=1:1:rownumber-1
    if particleid(i) ~= particleid(i+1)
        number_m=number_m+1;
    end
end  
particle=cell(1,number_m);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
j=1; %calculate times of jth particle repeating
repeat=ones(1,number_m); %k is a 1*number vector used to record repeat times 
for i=1:1:rownumber-1
    if particleid(i)== particleid(i+1)
        repeat(j)=repeat(j)+1;
    else
        j=j+1;
    end
end
c=0;
for a=1:1:number_m  %for ath partocle
   for b=1:1:repeat(a) %store line data for repeat(a) times 
    particle{a}(b,1)=particletime(c+1);
    particle{a}(b,2)=particleid(c+1);
    particle{a}(b,3)=xposition(c+1);
    particle{a}(b,4)=yposition(c+1);
    particle{a}(b,5)=zposition(c+1);
    c=c+1;
   end  
end
particle{1}=[]; % delete the first particle
particle{end}=[]; % delete the last particle
fprintf('store all data to particle.............. \n');