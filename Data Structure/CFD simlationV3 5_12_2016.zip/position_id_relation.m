relation=[];
for l=1:1:number_m
    haha=size(particle{l});
     haha=haha(1);
     if haha ~=0
    partid=particle{l}(1,2);
    relation(partid)=l;
%      else
%          re=[re NaN ];
     end
end
