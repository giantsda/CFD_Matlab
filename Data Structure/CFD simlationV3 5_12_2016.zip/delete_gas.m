function [timelimit]  = delete_gas (particle,number_m)
particle{1}=[]; % delete the first particle
particle{end}=[]; % delete the last particle
timevector_m=[];
    for d=1:1:number_m         % calcuate the avarage time period
        matrixsize=size(particle{d});
        matrixsize=matrixsize(1);
         if matrixsize ~=0
                time=particle{d}(:,1);
                time=time(end);
                timevector_m=[timevector_m time];
                d=d+1;
         end
    end
timevector= timevector_m;
mediantime=median(timevector); %average time for integration
timelimit=mediantime;


