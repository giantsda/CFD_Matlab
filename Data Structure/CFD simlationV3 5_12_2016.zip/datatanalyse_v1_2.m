% v1.2 modified at 11/24 add timefactor
% v1.1 modified at 11/23 because not all the particles have the same time period
% v1.0 modified at 11/23 because I choose to delete gas first and then calcuate
% the average time and introduce timelimit
%%%  %%%  %%   %%%  %%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%   read  %%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%  %%%  %%%  %%%%  %%% %
clc
clear % already use  i,j,a,b,c,d,e,f,g,h,i
timelimitfactor=0.8;
filename = 'C:\Users\chenshen\Desktop\CFD\10162015\41\41-120-50-sample.txt';
delimiterIn = '\t'; %read txt file
headerlinesIn = 13;
data = importdata(filename,delimiterIn,headerlinesIn);
    particletime=data.data(:, 1); %store data into column vecter;
    particleid=data.data(:, 2);
    xposition=data.data(:, 3);
    yposition=data.data(:, 4);
    zposition=data.data(:, 5);
    colour=data.data(:, 6); % 1.0for water, 0.0 for gas
    ber=size(particleid);%find how manys rows do I have ; ber is a vecter
    rownumber=ber(1);
    number=1; %number of different particle
    %%%%%%   %%%%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%    store data into {particle}  %% %%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%% %%%  %%%%   %%%%%
for i=1:1:rownumber-1
    if particleid(i) ~= particleid(i+1)
        number=number+1;
    end
end  
particle=cell(1,number);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
j=1; %calculate times of jth particle repeating
repeat=ones(1,number); %k is a 1*number vector used to record repeat times 
for i=1:1:rownumber-1
    if particleid(i)== particleid(i+1)
        repeat(j)=repeat(j)+1;
    else
        j=j+1;
    end
end
c=0;
for a=1:1:number  %for ath partocle
   for b=1:1:repeat(a) %store line data for repeat(a) times 
    particle{a}(b,1)=particletime(c+1);
    particle{a}(b,2)=particleid(c+1);
    particle{a}(b,3)=xposition(c+1);
    particle{a}(b,4)=yposition(c+1);
    particle{a}(b,5)=zposition(c+1);
    particle{a}(b,6)=colour(c+1);
    c=c+1;
   end  
end % here, all data are restored in particle
gas=[];
for d=1:1:number         % creat gas vecter to store particle ID which is gas finally.
   matrixsize=size(particle{d});
   matrixsize=matrixsize(1);
   if matrixsize ~=0 && particle{d}(end) <=0.1
      gas=[gas particle{d}(1,2)];
      particle{d}=[];
   end
end
timevector=[];
for d=1:1:number         % calcuate the avarage time period
    matrixsize=size(particle{d});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
            time=particle{d}(:,1);
            time=time(end);
            timevector=[timevector time];
            d=d+1;
     end
end
% % % % % % nbins = 1000;    %used for debuging
% % % % % % histfit(timevector,nbins);  %used for debuging
averagetime=mean(timevector) %average time for integration
timelimit=timelimitfactor*averagetime;
del=0;% how many particles I have deleted
for d=1:1:number % calcuate the avarage time period
     matrixsize=size(particle{d});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
        time=particle{d}(:,1);
        time=time(end);
            if time <timelimit
                particle{d}=[];   %delete  the particle if the time period is less than 0.8*average
                del=del+1;
            end
     end
end
%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
light=[];    % initialize result
 for e=1:1:number
     matrixsize=size(particle{e});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
        id=particle{e}(1,2);
        lightintegral=0;  %initial interal 
        f=0;
            for f=1:1:matrixsize-1
                  if particle{e}(f,1) <= timelimit
                        timestep=(particle{e}(f+1,1)-particle{e}(f,1)); % timestep=t2-t1
                        y1=particle{e}(f,4);  %store z position                          
                        y2=particle{e}(f+1,4);%store z position
                        x1=particle{e}(f,3);%convert m to cm
                        x2=particle{e}(f+1,3);%convert m to cm
                                                        light1=1.2/(exp(300*(x1)));   %state the light function           
                                                        light2=1.2/(exp(300*(x2)));  %state the light function 
%                                                         light1=1.2/(exp(300*(0.0241-x1)));   %state the light function           
%                                                         light2=1.2/(exp(300*(0.0241-x2)));  %state the light function 
%                         light1=1.2/(exp(300*( x1)));   %state the light function           
%                         light2=1.2/(exp(300*( x2)));  %state the light function                                  
                        integral=(light1+light2)*timestep/2;  %integral
                        lightintegral=lightintegral+integral;
                  else
                  break;
                  end
              end
     lightin=[id; lightintegral] ;%create a column vector so I can add it to vector [light]
     else
         lightin=[ ];
     end
      light=[light lightin]; %store light history into vecter light
 end
 
 %%%%%%%%%%%%%%%%%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%%%report%%%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
i=repeat(1);
avetimestep=averagetime%(particle{1}(i,1)-particle{1}(1,1))/i;
gaslenth =size(gas);
gaslenth=gaslenth(1,2);
x=light(1,:);    
y=light(2,:);
average=mean(y); %calcuate average
variance=var(y); % calcuate variance
    [ma,g]=max(y); % find the largest one `
    g=light(1,g);
    [mi,h]=min(y); % find the smallest one    
    hh=light(1,h);
         maxintegral=1.2*timelimit;
report = 'In this case %2.0f particles are tracked which%2.0f of them are escaped.Average time step is %5.6fs  \n';
fprintf(report,number,gaslenth,avetimestep)
report2 = '%2.0f particles are deleted because the time period is less than 0.8*ave. integration time period is%5.6fs \n';
fprintf(report2,del, timelimit)
report3 = 'The average of total light intensity is %4.5f the variance is %4.5f; The largest one \n is %4.5f of ID %4.0f; The smallest one is %4.5f of ID %4.0f \n';
fprintf(report3,average,variance,ma,g,mi,hh)
report4 = 'The light intensity function is  __light1=1.2/(exp(3*x1))__ maxium integral is%5.6f \n';
fprintf(report4,maxintegral)
lightxls=light.';
xlswrite ('C:\Users\chenshen\Desktop\CFD\Data Structure\light',lightxls); % generate a column excel file to save ID and Light 
figure
    nbins = 30;    %define figure elements
    histfit(y,nbins);  % generate a figure of light distribution
% % % % %     [ns mm] = hist(y, nbins)
% % % % %     hold on;
% % % % %     plot (mm,ns);
    xlabel('Total light intensity');
    ylabel('repeat times');
    title('Light distribution')
   
