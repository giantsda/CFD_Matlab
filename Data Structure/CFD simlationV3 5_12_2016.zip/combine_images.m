clc
clear
for i=1:1:221
simu=imread(['E:\desktop\New folder\1\' num2str(i) '.jpg']);
% figure(1)
% imshow(simu)
% size(simu)
real=imread(['E:\desktop\New folder\2\' num2str(i) '.jpg']);
% figure(2)
% imshow(real)
% size(real)
% for ii=1:1: 720
%     for jj=1:1:400
% combine(ii,jj,1,i)=simu(ii+209,jj+305,1);
% combine(ii,jj,2,i)=simu(ii+209,jj+305,2);
% combine(ii,jj,3,i)=simu(ii+209,jj+305,3);
%         if ii<=320 && jj<=300
% combine(ii+ 118,jj+400,1,i)=real(ii,jj+120,1);
% combine(ii+ 118,jj+400,2,i)=real(ii,jj+120,2);
% combine(ii+ 118,jj+400,3,i)=real(ii,jj+120,3);
%         end
%     end
% end
for ii=1:1: 720
combine(ii,1:960,1,i)=simu(ii,1:960,1);
combine(ii,1:960,2,i)=simu(ii,1:960,2);
combine(ii,1:960,3,i)=simu(ii,1:960,3);
combine(ii,961:1920,1,i)=real(ii,1:960,1);
combine(ii,961:1920,2,i)=real(ii,1:960,2);
combine(ii,961:1920,3,i)=real(ii,1:960,3);
end  
%  imshow(combine(:,:,:,i))
 M(i) = getframe; 
%  pause(0.000000001)
end
% movie2avi(M,'C:\Users\chenshen\Desktop\out7.avi','FPS',10,'quality',100) 
for o=1:1:221
    M(o).cdata=combine(:,:,:,o);
end
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    