function [light_m] = unsteady_light_int (number_m, particle,timelimit);
light_m=[];    % initialize result
 for e=1:1:number_m
     matrixsize=size(particle{e});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
        id=particle{e}(1,2);
        lightintegral=0;  %initial interal 
        f=0;
                for f=1:1:matrixsize-1
                  if particle{e}(f,1) <= timelimit
%                       if particle{e}(f,1) >= 40 && particle{e}(f,1)<=60
                        timestep=(particle{e}(f+1,1)-particle{e}(f,1)); % timestep=t2-t1 
                        x1=100*particle{e}(f,3);%convert m to cm
                        x2=100*particle{e}(f+1,3);%convert m to cm
                        y1=100*particle{e}(f,4);  %store z position                          
                        y2=100*particle{e}(f+1,4);%store z position
                        z1=100*particle{e}(f,5);%convert m to cm
                        z2=100*particle{e}(f+1,5);%convert m to cm                        
%                         light1=1.2/(exp(3*(x1)));   %state the light function           
%                         light2=1.2/(exp(3*(x2)));  %state the light function        
%                                     light1=get_light(x1,y1,15);
%                                     light2=get_light(x2,y2,15);
                                                            light1=1.2/(exp(3*(z1)));   %state the light function           
                                                            light2=1.2/(exp(3*(z2)));  %state the light function  
                            integral=(light1+light2)*timestep/2;  %integral
                            lightintegral=lightintegral+integral;
                  else
                  continue;
                      end
                end
     lightin=[id; lightintegral] ;%create a column vector so I can add it to vector [light]
     else
         lightin=[ ];
     end
      light_m=[light_m lightin]; %store light history into vecter light
 end

