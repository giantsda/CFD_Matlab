folder_path='E:\desktop\CFD\Dr Peers Reactor\';
file_name=['PT_large'];
filename1 = [folder_path '\' file_name '.csv'] 
delimiterIn = ','; %read txt file
headerlinesIn = 6;
data = importdata(filename1,delimiterIn,headerlinesIn);
xposition=data.data(:, 1); %store data into column vecter;
yposition=data.data(:, 2);
zposition=data.data(:, 3);
particleid=data.data(:, 4);
particletime=data.data(:, 5);
ber=size(particleid);%find how manys rows do I have ; ber is a vecter
rownumber=ber(1);
number_m=1; %number of different particle
%
for i=1:1:rownumber-1
    if particleid(i) ~= particleid(i+1)
        number_m=number_m+1;
    end
end  
particle=cell(1,number_m);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
j=1; %calculate times of jth particle repeating
repeat=ones(1,number_m); %k is a 1*number vector used to record repeat times 
for i=1:1:rownumber-1
    if particleid(i)== particleid(i+1)
        repeat(j)=repeat(j)+1;
    else
        j=j+1;
    end
end
c=0;
for a=1:1:number_m  %for ath partocle
   for b=1:1:repeat(a) %store line data for repeat(a) times 
    particle{a}(b,1)=particletime(c+1);
    particle{a}(b,2)=particleid(c+1);
    particle{a}(b,3)=xposition(c+1);
    particle{a}(b,4)=yposition(c+1);
    particle{a}(b,5)=zposition(c+1);
    c=c+1;
   end  
end
particle{1}=[]; % delete the first particle
particle{end}=[]; % delete the last particle
fprintf('store all data to particle.............. \n');
%%
% function show_streamline (particle, number) 
figure;
set(gcf,'outerposition',get(0,'screensize'));
clear M;
timelimitfactor=1;
timevector=[];
for d=1:1:number_m         % calcuate the avarage time period
    matrixsize=size(particle{d});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
            time=particle{d}(:,1);
            time=time(end); 
            timevector=[timevector time];
            d=d+1;
     end
end
mediumtime=median(timevector);
timelimit=timelimitfactor*mediumtime;
del=0;% how many particles I have deleted
% for d=1:1:number % calcuate the avarage time period
%      matrixsize=size(particle{d});
%       matrixsize=matrixsize(1);
%      if matrixsize ~=0
%         time=particle{d}(:,1);
%         time=time(end);
%             if time <timelimit
%                 particle{d}=[];   %delete  the particle if the time period is less than 0.8*average
%                 del=del+1;
%             end
%      end
% end
%%
i=1;
for e=1:1:100
%     e=121
matrixsize=size(particle{e});
matrixsize=matrixsize(1);
if matrixsize ~=0
lightintegral=0;  %initial interal 
f=0;
    for f=1:1:matrixsize-1
          if particle{e}(f,1) <= timelimit
                timestep=(particle{e}(f+1,1)-particle{e}(f,1)); % timestep=t2-t1
                y1=particle{e}(f,4);  %store z position                          
                y2=particle{e}(f+1,4);%store z position
                x1=particle{e}(f,3);%convert m to cm
                x2=particle{e}(f+1,3);%convert m to cm
                                                light1=1.2/(exp(300*(x1)));   %state the light function           
                                                light2=1.2/(exp(300*(x2)));  %state the light function 
%                                                         light1=1.2/(exp(300*(0.0241-x1)));   %state the light function           
%                                                         light2=1.2/(exp(300*(0.0241-x2)));  %state the light function 
%                         light1=1.2/(exp(300*( x1)));   %state the light function           
%                         light2=1.2/(exp(300*( x2)));  %state the light function                                  
                integral=(light1+light2)*timestep/2;  %integral
                lightintegral=lightintegral+integral;
          else
          break;
          end
      end
lightin=lightintegral;%create a column vector so I can add it to vector [light]
%%
time=particle{e}(:,1);
xp=100*particle{e}(:,3);
yp=100*particle{e}(:,4);
zp=100*particle{e}(:,5);
%% plot
subplot(2,1,1)
hold on;
k1=find(xp>-60 & xp<60 & zp<0);
k2=find(xp>60);
k3=find(xp>-60 & xp<60 & zp>0);
k4=find(xp<-60);
    l1=diff(k1);
    l2=find(l1>20);
    l2=k1(l2+1);
    % if  k1(1)~=1
    %     l2=[k1(1) ; l2];
    % end
    num_round=size(l2);
    num_round=num_round(1);
plot3(zp(k1), xp(k1), yp(k1),'r.','LineWidth',0.2)
plot3(zp(k2), xp(k2), yp(k2),'k.','LineWidth',0.2)
plot3(zp(k3), xp(k3), yp(k3),'b.','LineWidth',0.2)
plot3(zp(k4), xp(k4), yp(k4),'m.','LineWidth',0.2)
    xlabel('x')
    ylabel('z')
    zlabel('y')
    axis equal
xlim([-60 60])
ylim([-160 160])
zlim([0 25])
hold off;
view(-50,10);
% view(-90,0);
%%
subplot(2,1,2)
xlabel('time(s)')
ylabel('yposition')
ylim([0 22])
hold on;
plot(time(k1),yp(k1),'r.','MarkerSize',5);
plot(time(k2),yp(k2),'k.','MarkerSize',5);
plot(time(k3),yp(k3),'b.','MarkerSize',5);
plot(time(k4),yp(k4),'m.','MarkerSize',5);
plot(time(l2),yp(l2),'go','MarkerFaceColor','g');
% xlim([0 100])
hold off;
suptitle(['This the history of Particle ID=' num2str(e) 'roundnumber= ' num2str(num_round) ]);
%%
pause(  );      
end
%  M(i)=getframe(gcf);
 i=i+1
end
% movie2avi(M,'E:\desktop\temp\1.avi','FPS',10,'quality',100)
