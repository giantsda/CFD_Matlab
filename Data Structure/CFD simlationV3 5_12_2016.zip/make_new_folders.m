new_folder = 'C:\Users\chenshen\Desktop\CFD\Result validation\41\water'; 
for i=2000:1000:30000;
mkdir([new_folder '\' num2str(i) '_9.0s']);
end
