clc
clear
folder_path='C:\Users\chenshen\Desktop\temp';
file_name='surface';
[particle,name]=position_analysis(folder_path,file_name);
%         xlim1=2.4;         % for file 49
%         xlim2=2.41;
%         ylim1=7.006;
%         ylim2=7.016;
%         zlim1=5.692;
%         zlim2=5.71;
% xlim1=1.806;         % for file 41
% xlim2=1.813;
% ylim1=6.958;
% ylim2=6.9725;
% zlim1=5.9814;
% zlim2=5.99409;
% [idvector,number]=particle_loss_location(name,xlim1,xlim2,ylim1,ylim2,zlim1,zlim2)
%  M= show_lost_particle(particle,idvector,number)
% movie2avi(M,'C:\Users\chenshen\Desktop\temp\particle_loss.avi','FPS',5) 

% for l=50:1:60
% M(l).cdata=[]
% end