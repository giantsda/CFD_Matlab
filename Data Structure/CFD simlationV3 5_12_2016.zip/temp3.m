% function fig2movie2
% v = VideoWriter('2.avi');
% open(v)
% folder_path1='E:\desktop\temp\1\';
folder_path2='E:\desktop\temp\2\';
begin=1;
middle=1;
endd=999;
i=1;
name='AnimationFrame';
for rere=begin:middle:endd
    if rere>=1 && rere<10
     file_name=[name '00000' num2str(rere)];
    else if  rere>=10 && rere<100
     file_name=[name '0000' num2str(rere)];
        else
             file_name=[name '000' num2str(rere)];
        end
    end
% file_name=[num2str(rere)];
%      filename1 = [folder_path1   file_name '.jpg'] ;
     filename2 = [folder_path2   file_name '.jpg'] ;
% frame1=imread( filename1); 
frame2=imread( filename2); 
% for fps=1:1:4
% imwrite(frame, ['E:\desktop\temp\1out\' num2str(j) '.jpg'])
% j=j+1;
% writeVideo(v,frame)
% end
imshow(frame2)
%  frame2 = imresize(frame2, [960 720]);
imwrite(frame2, ['E:\desktop\temp\2out\' num2str(i) '.jpg'])
i=i+1
end
% close(v)
