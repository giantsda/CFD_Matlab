for i=1:1:221
    path='E:\desktop\New folder\2\';
   s=num2str(i);
   if i<10
       s=['000' s];
   else if i>=10 && i<100
       s=['00' s];
        else if i>=100 && i<1000
       s=['0' s];
            else if i>=1000 && i<10000
         s=['0' s];
          else 
            s=s;
                end
            end
       end
   end
oldfile=[path 'sequence-2_9_' s '.jpg']
newfile=[path num2str(i) '.jpg']
movefile(oldfile,newfile);
end
