clear;
% function [particle,number_m,timelimit]=unsteady_particle_tracking (folder_path,file_name)
folder_path='E:\desktop\CFD\long tracking time study\41';
file_name='3-39_1';
filename1 = [folder_path '\' file_name '.csv'] 
data = importdata(filename1);
xposition=data.data(:, 1); %store data into column vecter;
yposition=data.data(:, 2);
zposition=data.data(:, 3);
particleid=data.data(:, 4);
particletime=data.data(:, 5);
    ber=size(particleid);%find how manys rows do I have ; ber is a vecter
    rownumber=ber(1);
    number_m=1; %number of different particle
%%
for i=1:1:rownumber-1
    if particleid(i) ~= particleid(i+1)
        number_m=number_m+1;
    end
end  
particle=cell(1,number_m);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
j=1; %calculate times of jth particle repeating
repeat=ones(1,number_m); %k is a 1*number vector used to record repeat times 
for i=1:1:rownumber-1
    if particleid(i)== particleid(i+1)
        repeat(j)=repeat(j)+1;
    else
        j=j+1;
    end
end
c=0;
for a=1:1:number_m  %for ath partocle
   for b=1:1:repeat(a) %store line data for repeat(a) times 
    particle{a}(b,1)=particletime(c+1);
    particle{a}(b,2)=particleid(c+1);
    particle{a}(b,3)=xposition(c+1);
    particle{a}(b,4)=yposition(c+1);
    particle{a}(b,5)=zposition(c+1);
    c=c+1;
   end  
end
fprintf('store all data to particle.............. \n');
%%
timevector_m=[];
for d=1:1:number_m         % calcuate the avarage time period
    matrixsize=size(particle{d});
    matrixsize=matrixsize(1);
     if matrixsize ~=0
            time=particle{d}(:,1);
            time=time(end)-time(1);
            timevector_m=[timevector_m time];
            d=d+1;
     end
end
timevector= timevector_m;
mediantime=median(timevector); %average time for integration
timelimit=mediantime
%%
% delete for poor information particle
del_m=0;% how many particles I have deleted
ch=[];
for d=1:1:number_m              % calcuate the avarage time period
    repeatlimit=0.2*mean(repeat);
        if repeat(d) <repeatlimit 
            particle{d}=[];   %delete  the particle if the time period is less than 0.8*average
            del_m=del_m+1;
            tem=[d;repeat(d)];
            ch=[ch tem];
        end 
end
%%
light_m=[];    % initialize result
 for e=1:1:number_m
     matrixsize=size(particle{e});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
        id=particle{e}(1,2);
        lightintegral=0;  %initial interal 
        f=0;
            for f=1:1:matrixsize-1
                  if particle{e}(f,1) <= timelimit
                        timestep=(particle{e}(f+1,1)-particle{e}(f,1)); % timestep=t2-t1
                        y1=particle{e}(f,4);  %store z position                          
                        y2=particle{e}(f+1,4);%store z position
                        x1=particle{e}(f,3);%convert m to cm
                        x2=particle{e}(f+1,3);%convert m to cm
                        light1=1.2/(exp(300*x1));  %%%%%%%%%%%% %state the light function           
                        light2=1.2/(exp(300*x2));  %%%%%%%%%%%%%%state the light function 
                        integral=(light1+light2)*timestep/2;  %integral
                        lightintegral=lightintegral+integral;
                  else
                  break;
                  end
              end
     lightin=[id; lightintegral] ;%create a column vector so I can add it to vector [light]
     else
         lightin=[ ];
     end
      light_m=[light_m lightin]; %store light history into vecter light
 end
light=light_m;
%%
left=size(light);
left=left(2);
maxintegral=1.2*timelimit;
sma=0;      
for i=1:1:left
   if light(2,i) <  maxintegral*0.01
       sma=sma+1;
   end
end
light_001=[];
for i=1:1:left
   if light(2,i) >  maxintegral*0.01
      light_001=[light_001 light(:,i)];
   end
end 
y=light(2,:)/maxintegral; %nomolize the result
average=mean(y); %calcuate average
variance=var(y); % calcuate variance
[ma,g]=max(y); % find the largest one ` 
g=light(1,g);
[mi,h]=min(y); % find the smallest one    
hh=light(1,h);
%%
figure(1);
nbins = 200;    %define figure elements
histfit(y,nbins);  % generate a figure of light distribution
xlabel('Nomorlized total light intensity');
ylabel('repeat times');
title(['Nomorlized Light distribution of ___' file_name ]);
saveas(gcf,[folder_path '\' 'Nomorlized Light distribution of_' file_name  '.jpg']);
%%
figure(2); 
y_001=light_001(2,:)/maxintegral;%nomolize the result
histfit(y_001,nbins);  % generate a figure of light distribution
xlabel('Total light intensity');
ylabel('repeat times');
title(['Nomorlized Light distribution of particles larger than 0.01___' file_name ]);
saveas(gcf,[folder_path '\' 'Light distribution of_particles larger than 0.01__of ' file_name  '.jpg']);
%%
report1 = '>>>>>This is the report of unsteady particle tracking.<<<<< \nIn this case %2.0f particles are tracked.Medium time step is %5.6fs  \n';
fprintf(report1,number_m,mediantime)
report2 = '%2.0f particles are deleted because they are lost. Total line number is %6.0f \n';
fprintf(report2,del_m,rownumber)
report3= 'integration time period is %5.6fs. there are %3.0f particles left \n';
fprintf(report3,timelimit,left)
report4 = 'The average of total light intensity is<<%4.5f>>. The variance is %4.5f; \nThe largest one is %4.5f of ID %4.0f; The smallest one is %4.5f of ID %4.0f. \n';
fprintf(report4,average,variance,ma,g,mi,hh)
report5 = 'The light intensity function is  __light1=1.2/(exp(300*x))__ maxium integral is%5.6f. \n';
fprintf(report5,maxintegral)
report6= 'The average over the maxium integral is<<%4.5f>> %5.0f particles (%5.2fpercent) are smaill than 0.01*max \n';
fprintf(report6,average,sma,sma/left*100)
lightxls=light.';
%%                                       
name= [folder_path '\' 'light result of_' file_name '.xls'];
xlswrite (name,lightxls); 
