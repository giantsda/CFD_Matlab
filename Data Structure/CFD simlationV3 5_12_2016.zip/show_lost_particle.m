function M= show_lost_particle(particle,idvector,number)
%%
% for given idvector, this file gives Movie M.
long=size( idvector.final);
long=long(2);
ele_id_relation=[];
timelimitfactor=0.9;
for i=2:1:number
    id=particle{i}(1,2);
    ele_id_relation(id)=i;
end
%%
timevector=[];
for d=1:1:number         % calcuate the avarage time period
    matrixsize=size(particle{d});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
            time=particle{d}(:,1);
            time=time(end);
            timevector=[timevector time];
            d=d+1;
     end
end
mediumtime=median(timevector);
timelimit=timelimitfactor*mediumtime;
%%
del=0;% how many particles I have deleted
for d=1:1:number % calcuate the avarage time period
     matrixsize=size(particle{d});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
        time=particle{d}(:,1);
        time=time(end);
            if time <timelimit
                particle{d}=[];   %delete  the particle if the time period is less than 0.8*average
                del=del+1;
            end
     end
end
for i=1:1:long-1
    e=idvector.final(i+1);
    e=ele_id_relation(e);
matrixsize=size(particle{e});
matrixsize=matrixsize(1);
if matrixsize ~=0
xp=100*particle{e}(:,3);
yp=100*particle{e}(:,4);
zp=100*particle{e}(:,5);
    subplot(1,2,1)
    plot3(xp(1), zp(1),yp(1),'*' ,'MarkerSize',12);
  hold on;
    plot3(xp, zp,yp,'LineWidth',1);
    hold off;
    xlabel('x')
    ylabel('y')
    zlabel('z')
    axis equal
    xlim([-0.5  2.5])
    ylim([0 9])
    zlim([-2 15])
%%
subplot(1,2,2)
plot3(xp(1), zp(1),yp(1),'*' ,'MarkerSize',12);
  hold on;
plot3(xp, zp,yp,'LineWidth',1);
hold off;
xlabel('x')
ylabel('y')
zlabel('z')
% text(-4,7,7,[ 'Nomolized Light intensity Integration is   ' num2str(lightin/timelimit/1.2)]);
axis equal
xlim([-0.5  2.5])
ylim([0 9])
zlim([-2 15])
az = 0;
el = 0;
view(az, el);  
pause(0.00000005)      
end
 M(i)=getframe(gcf);
end
%  movie2avi(M,'C:\Users\chenshen\Desktop\temp\out1.avi','FPS',10) 