%% read .dpm file to use the first two lines
filename1='sample.dpm';
data = importdata(filename1);
% com=data;
siz=size(data);
siz=siz(1);
for i=3:1:siz
data{i}(1)=[];
data{i}(1)=[];
    for j=1:1:16
        data{i}(155)=[];
    end  
data{i}=str2num(data{i});    
end
%% generate writeinfo
numberpart=zeros(elen_x*elen_y*elen_z+2,12);
numberpart(:,7)=8e-5;  %define the diameter
d=8e-5;
mass=4/3*pi*(d/2)^3*1000; % calculate the mass
numberpart(:,8)=300; %define Temperature
numberpart(:,9)=2.1368e-23; %define mass-flow
numberpart(:,10)=2.68e-10; %define the mass
numberpart(:,11)=7.9705e-14; % define  frequency  
for i=1:elen_x*elen_y*elen_z %assign xyz postion to numberpart
numberpart(i+2,1:3)=ele_location(:,i);
writeinfo{i+2,1}=num2str(numberpart(i+2,:));
writeinfo{i+2,1}=['(( ' writeinfo{i+2,1} ') )'];
end
writeinfo{1}=data{1};
writeinfo{2}=data{2}; 
filename1=num2str(elen_x*elen_y*elen_z);
%% generate .inj file
fid=fopen(['E:\desktop\temp\' filename1 '.inj'],'wt');
report=['generating E:\desktop\temp\' filename1 '.inj....']
for i=1:elen_x*elen_y*elen_z+2
writ=writeinfo{i};
fprintf(fid,'%s\n',writ);
end
fclose(fid);
