% folder_path='E:\desktop\CFD\Dr Peers Reactor\';
% file_name=['PT_large'];
% filename1 = [folder_path '\' file_name '.csv'] 
% delimiterIn = ','; %read txt file
% headerlinesIn = 6;
% data = importdata(filename1,delimiterIn,headerlinesIn);
% xposition=data.data(:, 1); %store data into column vecter;
% yposition=data.data(:, 2);
% zposition=data.data(:, 3);
% particleid=data.data(:, 4);
% particletime=data.data(:, 5);
% ber=size(particleid);%find how manys rows do I have ; ber is a vecter
% rownumber=ber(1);
% number_m=1; %number of different particle
% %
% for i=1:1:rownumber-1
%     if particleid(i) ~= particleid(i+1)
%         number_m=number_m+1;
%     end
% end  
% particle=cell(1,number_m);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
% j=1; %calculate times of jth particle repeating
% repeat=ones(1,number_m); %k is a 1*number vector used to record repeat times 
% for i=1:1:rownumber-1
%     if particleid(i)== particleid(i+1)
%         repeat(j)=repeat(j)+1;
%     else
%         j=j+1;
%     end
% end
% c=0;
% for a=1:1:number_m  %for ath partocle
%    for b=1:1:repeat(a) %store line data for repeat(a) times 
%     particle{a}(b,1)=particletime(c+1);
%     particle{a}(b,2)=particleid(c+1);
%     particle{a}(b,3)=xposition(c+1);
%     particle{a}(b,4)=yposition(c+1);
%     particle{a}(b,5)=zposition(c+1);
%     c=c+1;
%    end  
% end
% particle{1}=[]; % delete the first particle
% particle{end}=[]; % delete the last particle
% fprintf('store all data to particle.............. \n');


number=number_m;
figure;
set(gcf,'outerposition',get(0,'screensize'));
clear M;
i=1;
for e=1:1:500
    e
                     e=randi([1 number]);
                 
matrixsize=size(particle{e});
matrixsize=matrixsize(1);
if matrixsize ~=0
lightintegral=0;  %initial interal 
f=0;
%     for f=1:1:matrixsize-1
%       if particle{e}(f,1) <= timelimit
%             timestep=(particle{e}(f+1,1)-particle{e}(f,1)); % timestep=t2-t1
%                     x1=100*particle{e}(f,3);%convert m to cm
%                     x2=100*particle{e}(f+1,3);%convert m to cm
%                     y1=100*particle{e}(f,4);  %store z position                          
%                     y2=100*particle{e}(f+1,4);%store z position
%                     z1=100*particle{e}(f,5);%convert m to cm
%                     z2=100*particle{e}(f+1,5);%convert m to cm                        
%     %                         light1=1.2/(exp(3*(x1)));   %state the light function           
%     %                         light2=1.2/(exp(3*(x2)));  %state the light function        
%     %                                     light1=get_light(x1,y1,15);
%     %                                     light2=get_light(x2,y2,15);
%                                                         light1=1.2/(exp(3*(z1)));   %state the light function           
%                                                         light2=1.2/(exp(3*(z2)));  %state the light function                                
%             integral=(light1+light2)*timestep/2;  %integral
%             lightintegral=lightintegral+integral;
%       else
%       break;
%       end
%     end
% lightin=lightintegral;%create a column vector so I can add it to vector [light]
%%
xp=100*particle{e}(:,3);
yp=100*particle{e}(:,4);
zp=100*particle{e}(:,5);
%     subplot(1,2,1)   
    plot3(zp, xp,yp,'LineWidth',0.5);
   
      hold on;
    xlabel('x')
    ylabel('z')
    zlabel('y')
    axis equal
xlim([-3.1357 3.1357])
ylim([-3.1357 3.1357])
zlim([0  28])
%     text(0,0,0,[ 'Nomolized Light intensity Integration is   ' num2str(lightin/timelimit/1.2)]);
%%
% subplot(1,2,2)
% plot3(xp, zp,yp,'LineWidth',0.5);
% %   hold on;
% xlabel('x')
%     ylabel('z')
%     zlabel('y')
% axis equal
% xlim([-160 160])
% ylim([-60 60])
% zlim([0 25])
% az = 90; 
% el = 0;
% view(az, el);  
%%
%                                                                                                         subplot(2,2,3)
%                                                                                                         plot3(xp, zp,yp,'LineWidth',0.5);
%                                                                                                         %   hold on;
%                                                                                                         xlabel('x')
%                                                                                                             ylabel('z')
%                                                                                                             zlabel('y')
%                                                                                                         axis equal
%                                                                                                            xlim([-4  4])  
%                                                                                                             ylim([-4 8])
%                                                                                                             zlim([-1 12])
%                                                                                                         az = 90; 
%                                                                                                         el = 0;
%                                                                                                         view(az, el);  
%                                                                                                         %%
%                                                                                                         subplot(2,2,4)
%                                                                                                         plot3(xp, zp,yp,'LineWidth',0.5);
%                                                                                                         %   hold on;
%                                                                                                         xlabel('x')
%                                                                                                             ylabel('z')
%                                                                                                             zlabel('y')
%                                                                                                         axis equal
%                                                                                                            xlim([-4  4])  
%                                                                                                             ylim([-4 8])
%                                                                                                             zlim([-1 12])
%                                                                                                         az = 0; 
%                                                                                                         el = 90;
%                                                                                                         view(az, el);  
pause( 0);      
end

%  M(i)=getframe(gcf);
 i=i+1;
end
%  movie2avi(M,'E:\desktop\temp\2.avi','FPS',30,'quality',100) 
% saveas(gcf,[folder_path '\' 'Pathline '   '.jpg']);