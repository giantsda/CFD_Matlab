function  [particle,del_m,ch_m]  = unsteady_delete_poor_par (particle,number_m,repeat);
del_m=0;% how many particles I have deleted
ch_m=[];
for d=1:1:number_m              % calcuate the avarage time period
    repeatlimit=0.3*mean(repeat);
        if repeat(d) <repeatlimit 
            particle{d}=[];   %delete  the particle if the time period is less than 0.8*average
            del_m=del_m+1;
            tem=[d;repeat(d)];
            ch_m=[ch_m tem];
        end 
end