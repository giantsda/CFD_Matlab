mov=VideoReader('E:\desktop\1.avi'); 
numFrames = mov.NumberOfFrames
path='E:\desktop\temp\Dr Peers Reactor\2\';
j=1;
 for i = 8 : 5: 2500 
     frame = read(mov,i);
%      imshow(frame); 
%        if i>0 && i<10
%         imwrite(frame,[path '\0000' num2str(i)  '.jpg']);
%             else if i>=10 && i<100
%                 imwrite(frame,[path '\000' num2str(i)  '.jpg']);  
%                     else if i>=100 && i<1000
%                     imwrite(frame,[path '\00' num2str(i)  '.jpg']);  
%                             else if i>=1000 && i<10000
%                             imwrite(frame,[path '\0' num2str(i)  '.jpg']);  
%                             else
%                             imwrite(frame,[path '\' num2str(i)  '.jpg']);  
%                             end
%                     end
%                 end
%        end2
for omo=1:1:2
 imwrite(frame,[path  num2str(j)  '.jpg']);
 j=j+1;
end
       if rem(i,100)==0
           i
           numFrames
       end
 end