% function [particle,name]=position_analysis(folder_path,file_name)
%%
% for a given txt file (folder_path,file_name), gives a xls flie, two
% figures, name is the path of the xls file 

% folder_path='E:\desktop\CFD\scale study\24';
% file_name='24_1';
% filename1 = [folder_path '\' file_name '.his'] 
% % filename1='C:\Users\chenshen\Desktop\CFD\Result validation\41\water\5000\5000.txt';
% %% read .his file
% delimiterIn = '\t'; %read txt file
% headerlinesIn = 13;
% data = importdata(filename1,delimiterIn,headerlinesIn);
%     particletime=data.data(:, 1); %store data into column vecter;
%     particleid=data.data(:, 2);
%     xposition=data.data(:, 3);
%     yposition=data.data(:, 4);
%     zposition=data.data(:, 5);
%     colour=data.data(:, 6); % 1.0for water, 0.0 for gas
%     ber=size(particleid);%find how manys rows do I have ; ber is a vecter
%     rownumber=ber(1);
% %% find out the number of particle put information into particle
% number_m=1; %number of different particle
% for i=1:1:rownumber-1
%     if particleid(i) ~= particleid(i+1)
%         number_m=number_m+1;
%     end
% end  
% particle=cell(1,number_m);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
% j=1; %calculate times of jth particle repeating
% repeat=ones(1,number_m); %k is a 1*number vector used to record repeat times 
% for i=1:1:rownumber-1
%     if particleid(i)== particleid(i+1)
%         repeat(j)=repeat(j)+1;
%     else
%         j=j+1;
%     end
% end
% c=0;
% for a=1:1:number_m  %for ath partocle
%    for b=1:1:repeat(a) %store line data for repeat(a) times 
%     particle{a}(b,1)=particletime(c+1);
%     particle{a}(b,2)=particleid(c+1);
%     particle{a}(b,3)=xposition(c+1);
%     particle{a}(b,4)=yposition(c+1);
%     particle{a}(b,5)=zposition(c+1);
%     particle{a}(b,6)=colour(c+1);
%     c=c+1;
%    end  
% end % here, all data are restored in particle
% fprintf('store all data to particle.............. \n');
%%
xpi_store=[];
ypi_store=[];
zpi_store=[];
xpf_store=[];
ypf_store=[];
zpf_store=[];
for i=1:1:number-1
xpi(:,i)=[100*particle{i}(1,3);particle{i}(1,2)];
ypi(:,i)=[100*particle{i}(1,4);particle{i}(1,2)];
zpi(:,i)=[100*particle{i}(1,5);particle{i}(1,2)];

xpf(:,i)=[100*particle{i}(end,3);particle{i}(1,2)];
ypf(:,i)=[100*particle{i}(end,4);particle{i}(1,2)];
zpf(:,i)=[100*particle{i}(end,5);particle{i}(1,2)];

end
xpi_store=[xpi_store xpi];
ypi_store=[ypi_store ypi];
zpi_store=[zpi_store zpi];
xpf_store=[xpf_store xpf];
ypf_store=[ypf_store ypf];
zpf_store=[zpf_store zpf];

 %%                         
        position_info=[xpi_store;ypi_store;zpi_store;xpf_store;ypf_store;zpf_store];
        position_info=position_info.';
        name=[folder_path '\' ' finial position infomation of_' file_name  '.xls'];
%         xlswrite (name,position_info);
 %%  
 figure;
subplot(1,2,1)
plot3(xpi_store(1,:),ypi_store(1,:),zpi_store(1,:),'.','MarkerSize',4);
axis equal
xlabel('x')
ylabel('y')
zlabel('z')
title('initial')

subplot(1,2,2)
plot3(xpf_store(1,:),ypf_store(1,:),zpf_store(1,:),'.','MarkerSize',4);
axis equal
xlabel('x')
ylabel('y')
zlabel('z')
title('final')
% saveas(gcf,[folder_path '\' 'initial final position of_' file_name  '.jpg']);

figure
subplot(3,1,1);
hist(xpf_store(1,:),500);
title('xposition');
subplot(3,1,2);
hist(ypf_store(1,:),500);
title('yposition');
subplot(3,1,3);
hist(zpf_store(1,:),500);
title('zposition');
% saveas(gcf,[folder_path '\' 'spatial position of_' file_name  '.jpg']);

% end