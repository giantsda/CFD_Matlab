% function movie_of_distribution(folder_path,factorvector,begin,endd,middle,ii)
% factor=[0.88 1.466 6.675 13.24 26 37.88 72.53];
% number=7;
folder_path='C:\Users\chenshen\Desktop\CFD\Result validation\41\water';
%%
dat= importdata('C:\Users\chenshen\Desktop\CFD\Result validation\41\water\water design.xlsx');
factor=dat.data(:,12);
factor=factor(40:end);
ii=10;
for rere=1000:1000:30000
% figure;
file_name=num2str(rere);
filename1 = [folder_path '\' file_name '_9.0s\'  file_name '.xls'] 
light = importdata(filename1);
y =light(:,2)/factor(ii);
nbins =300;    %define figure elements
%                 light_001=[];
%                 left=size(light);
%                 left=left(1);
%                     for i=1:1:left
%                         if light(i,2) >  factor(ii)*1.2*0.8*0.01
%                                  light_001=[light_001; light(i,:)];
%                         end
%                     end
%                 y_001=light_001(:,2)/factor(ii);
%                 histfit(y_001,nbins);  % generate a figure of light distribution
%                 xlabel('Total light intensity');
%                 ylabel('repeat times');
%                 title(['Light distribution of_particles larger than 0.01\_\_' file_name '_' ]);
%                 xlim([0 1]);
hist(y,nbins);  % generate a figure of light distribution
xlabel('Total light intensity');
ylabel('repeat times');
title(['Light distribution of_' file_name '_' ]);
xlim([0 1]);
pause(0.0005);
 saveas(gcf,['C:\Users\chenshen\Desktop\temp\no escape\'  num2str(ii) '.bmp']);
 ii=ii+1;
end