Ultra File Splitter
Copyright (C) 2009 ZhangLuduo. 
All Rights Reserved.

============
Introduction
============

Ultra File Splitter is used for splitting large file to pieces for 
easy moving, storing, emailing, or other. Ultra File Splitter be 
able to handle file sizes up to 16EB, and supports any file types. 
In addition, your friend without this software still be combine 
your splitted files. This allows others without this software 
combine your splitted files.

========
Features
========

* Easy-to-use
* Support any type of files
* Support huge file (up to 16 EB)
* Create self-combination batch file
* Support drag and drop
* Support MD5 value calculate

===========
Limitations
===========

Ultra File Splitter is a shareware. Before registration you only 
use 5 times and you may use this software for trial purposes 
without any charges. If you think it's useful, you should pay 
registration fee. See 'Order' section below.

==================
System Requirement
==================

Ultra File Splitter works on all 32-bit Microsoft Windows Systems 
that include Win98, WinME, WinNT, Win2K, WinXP and Win2003, etc.

============
Installation
============

Double-click installation file to install and follow the step 
by step instructions.


==============
Uninstallation
==============

Click Start menu->Programs->Ultra File Splitter->Uninstall

=====
Order
=====

Price: $19.95 USD
You can order this software from 
http://www.zhangluduo.com/filesplitter/

========
Feedback
========

For feedback, questions and any comments:
E-mail: Support@zhangluduo.com

Web site: 
http://www.zhangluduo.com/
Support mail: 
Support@zhangluduo.com