x=linspace(0.2,10,100);
y=x.^10;
x=log(x);
y=log(y);
p=polyfit(x,y,1)
 