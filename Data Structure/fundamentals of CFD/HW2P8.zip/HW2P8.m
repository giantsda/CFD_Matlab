%% 1D problem
clear all; % clear all data
low=0; % define my low and high spatial boundary
high=1;
M=50; % number of grids
a=1; % a is the coefficient 
dx=(high-low)/M;  
out=[]; % output file which the solution of each time ste can be found here
un=zeros(1,M); % initialize my IC vector;
pos=(high-low)/(M)*([0:(M-1)]); % calculate position value at each grid
%% set IC
for i=1:M
        un(i)=exp(-0.5*((pos(i)-0.5)/0.08)^2);
end
u_ic=un; %% save my IC so I can compare with my soilution
%% set A
B1=zeros(M);
B2=zeros(M);
for i=2:M-1
    B1(i,i-1)=-1;
    B1(i,i+1)=1;
    B2(i,i-1)=1;
    B2(i,i+1)=1;
    B2(i,i)=4;
end
B1(1,2)=1;
B1(1,end)=-1;
B1(M,1)=1;
B1(M,M-1)=-1;
B2(1,1:2)=[4 1];
B2(1,end)=1;
B2(end,1)=1;
B2(end,end-1:end)=[1 4];
un=un.';
operator_4O_corrector=6*inv(B2)*1/2/dx*B1; % Define my 4-order centered differences operator;
%% different time martching methods

%% Explicit Euler
h=dx*a*0.1; % Courant number=0.1
for t=1:(1/h)
    unp1=un+operator_4O_corrector*un*h; % unp1 stands for Un+1;
    un=unp1;
    out=[out ; unp1.'];
end
plot(pos,out(end,:),'o-');
hold on;

%% AB2
h=dx*a*0.1; % Courant number=0.1
out=[];
unm1=u_ic.';
un=unm1+1/2/dx*B1*unm1*h;
for t=1:(1/h)
    unp1=un+1/2*h*(1.5/dx*B1*un-operator_4O_corrector*unm1);
    unm1=un;
    un=unp1;
   out=[out ; unp1.'];
end
plot(pos,out(end,:),'*-');

%% implicit Euler
h=dx*a*0.1; % Courant number=0.1
out=[];
un=u_ic.';
B1=(h*operator_4O_corrector*dx-eye(M));
for t=1:(1/h)
  unp1=B1\(-un);
    un=unp1;
out=[out ; unp1.'];
end
plot(pos,out(end,:),'.-');


%% trapezoidal
h=dx*a*0.1; % Courant number=0.1
out=[];
un=u_ic.';
for t=1:(1/h)
    unp1=(1/2*h*operator_4O_corrector-eye(M))\(-(eye(M)+1/2*h*operator_4O_corrector)*un);
    un=unp1;
    out=[out ; unp1.'];
end
plot(pos,out(end,:),'x-');


%% 4th-order Runge-Kutta methods
h=a*dx; % Courant number=1
out=[];
un=u_ic.';
for t=1:(1/h)
    unp1d2_1=un+1/2*h*operator_4O_corrector*un;
    unp1d2_2=un+1/2*h*operator_4O_corrector*unp1d2_1;
    unp1_bar=un+h*operator_4O_corrector*unp1d2_2;
    unp1=un+1/6*h*(operator_4O_corrector*(un+2*unp1d2_1+2*unp1d2_2+unp1_bar));
    un=unp1;
    out=[out ; unp1.'];
end
plot(pos,out(end,:),'-*');


plot(pos,u_ic,'-^');
legend(' Explicit Euler','AB2','implicit Euler','trapezoidal',' 4th-order Runge-Kutta','exact solution');

 
