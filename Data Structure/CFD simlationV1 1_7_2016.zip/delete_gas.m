function [particle,timevector_m,gas_m]  = delete_gas (particle,number_m)
gas_m=[];
    for d=1:1:number_m         % creat gas vecter to store particle ID which is gas finally.
       matrixsize=size(particle{d});
       matrixsize=matrixsize(1);
       if matrixsize ~=0 && particle{d}(end) <=0.1
          gas_m=[gas_m particle{d}(1,2)];
          particle{d}=[];
       end
    end
particle{1}=[]; % delete the first particle
particle{end}=[]; % delete the last particle
timevector_m=[];
    for d=1:1:number_m         % calcuate the avarage time period
        matrixsize=size(particle{d});
        matrixsize=matrixsize(1);
         if matrixsize ~=0
                time=particle{d}(:,1);
                time=time(end);
                timevector_m=[timevector_m time];
                d=d+1;
         end
    end
end


% averagetime_m=mean(timevector_m); %average time for integration
% timelimit_m=timelimitfactor*averagetime_m;
% del_m=0;% how many particles I have deleted
% for d=1:1:number_m % calcuate the avarage time period
%      matrixsize=size(particle{d});
%       matrixsize=matrixsize(1);
%      if matrixsize ~=0
%         time=particle{d}(:,1);
%         time=time(end);
%             if time <timelimit_m
%                 particle{d}=[];   %delete  the particle if the time period is less than 0.8*average
%                 del_m=del_m+1;
%             end
%      end
% end
% particle{1}=[]; % delete the first particle
% particle{end}=[]; % delete the last particle
% del_m=del_m+2; % add these two


