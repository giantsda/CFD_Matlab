clc
clear
miao = importdata('C:\Users\chenshen\Desktop\CFD\Result validation\41\water\water design.xlsx');
% factorvector=[0.9593 7.2188 12.14 19.7 1.174 10.649 20.79 42.331 0.95 7.045 12.46 21.63];
factorvector=miao.data(:,12);
folder_path='C:\Users\chenshen\Desktop\CFD\Result validation\41\water';
begin=100;
endd=1000;
movie_of_distribution(folder_path,factorvector,begin,endd,100,1)
begin=1000;
endd=20000;
movie_of_distribution(folder_path,factorvector,begin,endd,1000,10)
begin=20000;
endd=26000;
movie_of_distribution(folder_path,factorvector,begin,endd,1000,29)