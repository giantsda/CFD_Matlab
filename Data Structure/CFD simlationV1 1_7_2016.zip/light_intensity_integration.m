function [light_m] = light_intensity_integration (number_m, particle,timelimit)
light_m=[];    % initialize result
 for e=1:1:number_m
     matrixsize=size(particle{e});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
        id=particle{e}(1,2);
        lightintegral=0;  %initial interal 
        f=0;
            for f=1:1:matrixsize-1
                  if particle{e}(f,1) <= timelimit
                        timestep=(particle{e}(f+1,1)-particle{e}(f,1)); % timestep=t2-t1
                        y1=particle{e}(f,4);  %store z position                          
                        y2=particle{e}(f+1,4);%store z position
                        x1=particle{e}(f,3);%convert m to cm
                        x2=particle{e}(f+1,3);%convert m to cm
                        light1=1.2/(exp(300*x1));  %%%%%%%%%%%% %state the light function           
                        light2=1.2/(exp(300*x2));  %%%%%%%%%%%%%%state the light function 
                        integral=(light1+light2)*timestep/2;  %integral
                        lightintegral=lightintegral+integral;
                  else
                  break;
                  end
              end
     lightin=[id; lightintegral] ;%create a column vector so I can add it to vector [light]
     else
         lightin=[ ];
     end
      light_m=[light_m lightin]; %store light history into vecter light
 end
     
end
