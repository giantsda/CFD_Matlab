for i=1:1:1810
    path='C:\Users\chenshen\Desktop\CFD\10162015\41\figures\real\';
   s=num2str(i);
   if i<10
       s=['0000' s];
   else if i>=10 && i<100
       s=['000' s];
        else if i>=100 && i<1000
       s=['00' s];
            else if i>=1000 && i<10000
         s=['0' s];
          else 
            s=s;
                end
            end
       end
   end
   oldfile=[path s '.jpg']
   newfile=[path num2str(i) '.jpg']
     movefile(oldfile,newfile);
end
