clc
clear % already use  i,j,a,b,c,d,e,f,g,h,i
filename = 'C:\Users\chenshen\Desktop\CFD\Data Structure\data structure sample\4211_50000_0_1.txt';
delimiterIn = '\t'; %read txt file
headerlinesIn = 13;
data = importdata(filename,delimiterIn,headerlinesIn);
    particletime=data.data(:, 1); %store data into column vecter;
    particleid=data.data(:, 2);
    xposition=data.data(:, 3);
    yposition=data.data(:, 4);
    zposition=data.data(:, 5);
    colour=data.data(:, 6); % 1.0for water, 0.0 for gas
    ber=size(particleid);%find how manys rows do I have ; ber is a vecter
    rownumber=ber(1);
    number=1; %number of different particle
    %%%%%%   %%%%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%%    store data into {particle}  %% %%%  %%%  %%   %%%%%%  %%%  %%   %%%%%%  %%%  %%   %%% %%for i=1:1:rownumber-1
for i=1:1:rownumber-1
    if particleid(i) ~= particleid(i+1)
        number=number+1;
    end
end  
particle=cell(1,number);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
j=1; %calculate times of jth particle repeating
repeat=ones(1,number); %k is a 1*number vector used to record repeat times 
for i=1:1:rownumber-1
    if particleid(i)== particleid(i+1)
        repeat(j)=repeat(j)+1;
    else
        j=j+1;
    end
end
c=0;
c=0;
for a=1:1:number  %for ath partocle
   for b=1:1:repeat(a) %store line data for repeat(a) times 
    particle{a}(b,1)=particletime(c+1);
    particle{a}(b,2)=particleid(c+1);
    particle{a}(b,3)=xposition(c+1);
    particle{a}(b,4)=yposition(c+1);
    particle{a}(b,5)=zposition(c+1);
    particle{a}(b,6)=colour(c+1);
    c=c+1;
   end  
end % here, all data are restored in particle
timevector=[];
for d=1:1:number         % calcuate the avarage time period
    matrixsize=size(particle{d});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
            time=particle{d}(:,1);
            time=time(end);
            timevector=[timevector time];
            d=d+1;
     end
end
yposition=particle{1,1}(:, 4);
xposition=particle{1,1}(:, 3);
time=particle{1,1}(:, 1);
subplot(2,2,1);
plot(time,xposition);
title(filename)
datasize=size(xposition);
datasize=datasize(1,1);
xresult=[];
for i=1:1:datasize
    xlight=1.2./(exp(300.*xposition(i)));
    xresult=[xresult; xlight];
end
subplot(2,2,2);
plot(time,xresult);
text(pi,20,'\leftarrow sin(\pi)')
inini=trapz(time,xresult)
res= num2str(inini)
timeperiod=timevector
total=num2str(timeperiod*1.2);
title([res,'  ',total])
rownumber=repeat




