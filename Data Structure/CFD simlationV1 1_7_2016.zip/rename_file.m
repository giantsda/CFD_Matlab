function rename_file (folder_path, file_name,file_number)
    for i=1:1:file_number
        s = num2str(i);
        if i<10
        newpath=[folder_path '\' file_name '.txt.00' s];% for example 'C:\Users\chenshen\Desktop\temp\New folder (2)\12_20.txt.001'
        else
        newpath=[folder_path '\' file_name '.txt.0' s] ;% for example 'C:\Users\chenshen\Desktop\temp\New folder (2)\12_20.txt.012'
        end
        newname=[folder_path '\' file_name '_' s '.txt' ];% for example 'C:\Users\chenshen\Desktop\temp\New folder (2)\12_20_1.txt'
        movefile(newpath,newname);
    end

