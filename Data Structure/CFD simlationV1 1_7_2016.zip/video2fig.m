mov=VideoReader('C:\Users\chenshen\Desktop\CFD\10162015\41\figures\IMG_0550.MOV'); 
i=1;
path='C:\Users\chenshen\Desktop\CFD\10162015\41\figures\real';
while hasFrame(mov)
video(:,:,:,i) = readFrame(mov);
imshow(video(:,:,:,i))
    if i>0 && i<10
    imwrite(video(:,:,:,i),[path '\0000' num2str(i)  '.jpg']);
        else if i>=10 && i<100
            imwrite(video(:,:,:,i),[path '\000' num2str(i)  '.jpg']);  
                else if i>=100 && i<1000
                imwrite(video(:,:,:,i),[path '\00' num2str(i)  '.jpg']);  
                        else if i>=1000 && i<10000
                        imwrite(video(:,:,:,i),[path '\0' num2str(i)  '.jpg']);  
                        else
                        imwrite(video(:,:,:,i),[path '\' num2str(i)  '.jpg']);  
                        end
                end
        end
    end
i=i+1;
% pause(0.5);
end


