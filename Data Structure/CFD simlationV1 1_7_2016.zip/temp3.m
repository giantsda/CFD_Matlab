%%
%define and initialization
clc;
clear;
%                                     ll='14000';
%                                     folder_path=['C:\Users\chenshen\Desktop\CFD\Result validation\41\water\' ll '_9.0s'];
%                                     file_name=ll;
folder_path='C:\Users\chenshen\Desktop\temp\debug';
file_name='500';
timelimitfactor=0.9;
timevector=[];
del=0;
gas=[];
light=[];
[file_number] = get_file_number (folder_path, file_name);
% file_number=file_number-1;
file_number=44
% rename_file (folder_path, file_name,file_number)
%%
% in order to get timelimit
line_vector=[];
asa=[];
for file_repeat=1:1:44
%         file_repeat=4;
        [particle,number_m] = read_data_and_store_data (folder_path, file_name,file_repeat,line_vector);
        [particle,timevector_m,gas_m]  = delete_gas (particle,number_m);
        timevector= timevector_m;
        mediantime=median(timevector); %average time for integration
        timelimit=timelimitfactor*mediantime
        asa=[asa timelimit];
end