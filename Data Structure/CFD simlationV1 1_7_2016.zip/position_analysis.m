% function position_analysis(file_name)

%                             folder_path='C:\Users\chenshen\Desktop\CFD\Result validation\41\water\21000_9.0s';
%                             file_name='21000';
xpi_store=[];
ypi_store=[];
zpi_store=[];
xpf_store=[];
ypf_store=[];
zpf_store=[];
for  repeat1=1:1:3
                            file_name_i=[folder_path '\' file_name '_' num2str(repeat1) '.txt']
%  file_name_i ='C:\Users\chenshen\Desktop\CFD\Result validation\41\water\7000_9.0s\7000.txt';        
delimiterIn = '\t'; %read txt file
headerlinesIn = 13;
data = importdata(file_name_i,delimiterIn,headerlinesIn);
    particletime=data.data(:, 1); %store data into column vecter;
    particleid=data.data(:, 2);
    xposition=data.data(:, 3);
    yposition=data.data(:, 4);
    zposition=data.data(:, 5);
    colour=data.data(:, 6); % 1.0for water, 0.0 for gas
    ber=size(particleid);%find how manys rows do I have ; ber is a vecter
    rownumber=ber(1);
    number=1; %number of different particle
%%
fprintf('store all data to data......... \n');
for i=1:1:rownumber-1
    if particleid(i) ~= particleid(i+1)
        number=number+1;
    end
end  
particle=cell(1,number);  %create number matrixs to store my data,called particle{1}, particle{2}...particle{number}
j=1; %calculate times of jth particle repeating
repeat=ones(1,number); %k is a 1*number vector used to record repeat times 
for i=1:1:rownumber-1
    if particleid(i)== particleid(i+1)
        repeat(j)=repeat(j)+1;
    else
        j=j+1;
    end
end
c=0;
for a=1:1:number  %for ath partocle
   for b=1:1:repeat(a) %store line data for repeat(a) times 
                particle{a}(b,1)=particletime(c+1);
                particle{a}(b,2)=particleid(c+1);
                particle{a}(b,3)=xposition(c+1);
                particle{a}(b,4)=yposition(c+1);
                particle{a}(b,5)=zposition(c+1);
                particle{a}(b,6)=colour(c+1);
                c=c+1;
   end  
end
fprintf('store all data to particle........ \n');
for i=1:1:number-1
xpi(:,i)=[100*particle{i}(1,3);particle{i}(1,2)];
ypi(:,i)=[100*particle{i}(1,4);particle{i}(1,2)];
zpi(:,i)=[100*particle{i}(1,5);particle{i}(1,2)];

xpf(:,i)=[100*particle{i}(end,3);particle{i}(1,2)];
ypf(:,i)=[100*particle{i}(end,4);particle{i}(1,2)];
zpf(:,i)=[100*particle{i}(end,5);particle{i}(1,2)];

end
xpi_store=[xpi_store xpi];
ypi_store=[ypi_store ypi];
zpi_store=[zpi_store zpi];
xpf_store=[xpf_store xpf];
ypf_store=[ypf_store ypf];
zpf_store=[zpf_store zpf];

end
 %%                         
% %         plp=[xpi_store;ypf_store;zpf_store];
% %         plp=plp.';
% %         name= ['C:\Users\chenshen\Desktop\temp\positioninfo.xls'];
% %         xlswrite (name,plp);
 %%  
 figure;
subplot(1,2,1)
plot3(xpi_store(1,:),ypi_store(1,:),zpi_store(1,:),'.','MarkerSize',4);
axis equal
xlabel('x')
ylabel('y')
zlabel('z')
title('initial')

subplot(1,2,2)
plot3(xpf_store(1,:),ypf_store(1,:),zpf_store(1,:),'.','MarkerSize',4);
axis equal
xlabel('x')
ylabel('y')
zlabel('z')
title('final')

figure
subplot(3,1,1);
hist(xpf_store(1,:),500);
title('xposition');
subplot(3,1,2);
hist(ypf_store(1,:),500);
title('yposition');
subplot(3,1,3);
hist(zpf_store(1,:),500);
title('zposition');
% end