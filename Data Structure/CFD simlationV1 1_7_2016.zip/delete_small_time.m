function [particle,del_m]  = delete_small_time (particle,number_m,timelimit)
del_m=0;% how many particles I have deleted
for d=1:1:number_m              % calcuate the avarage time period
     matrixsize=size(particle{d});
      matrixsize=matrixsize(1);
     if matrixsize ~=0
        time=particle{d}(:,1);
        time=time(end);
            if time <timelimit
                particle{d}=[];   %delete  the particle if the time period is less than 0.8*average
                del_m=del_m+1;
            end
     end
end
del_m=del_m+2; % add these two
end
