clc
clear
for i=1:1:400
simu=imread(['C:\Users\chenshen\Desktop\CFD\10162015\41\figures\simulation\' num2str(i) '.jpg']);
% im2double(simu);
% imshow(simu)
% size(simu)
real=imread(['C:\Users\chenshen\Desktop\CFD\10162015\41\figures\real\' num2str(2*i) '.jpg']);
% imshow(real)
% size(real)
for ii=1:1: 442
    for jj=1:1:400
combine(ii,jj,1,i)=simu(ii+209,jj+305,1);
combine(ii,jj,2,i)=simu(ii+209,jj+305,2);
combine(ii,jj,3,i)=simu(ii+209,jj+305,3);
        if ii<=320 && jj<=300
combine(ii+ 118,jj+400,1,i)=real(ii,jj+120,1);
combine(ii+ 118,jj+400,2,i)=real(ii,jj+120,2);
combine(ii+ 118,jj+400,3,i)=real(ii,jj+120,3);
        end


    end
end
 imshow(combine(:,:,:,i))
 M(i) = getframe; 
 pause(0.0000001)
end
movie2avi(M,'C:\Users\chenshen\Desktop\out7.avi','FPS',3,'quality',100,'compression', '20') 
% combine()